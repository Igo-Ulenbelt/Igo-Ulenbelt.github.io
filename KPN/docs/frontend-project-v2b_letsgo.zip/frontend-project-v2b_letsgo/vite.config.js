import { defineConfig } from 'vite';

export default defineConfig({
    base: '/frontend-project-v2b_letsgo/',
    server: {
        fs: {
            strict: false,
        },
    },
    build: {
        assetsInclude: ['**/*.json'], // Ensures .json files are properly included
        rollupOptions: {
            output: {
                manualChunks: {
                    // No need to define chunks for public files explicitly
                },
            },
        },
    },
});

## Team Afspraken

Hier staan de afspraken waar we moeten aan houden tijdens het project. 




- We zorgen ervoor dat iedereens werk in verhouding met elkaar staat, zodat er geen grote verschillen ontstaan in hoeveel iemand heeft gedaan.

- We streven ernaar om de opdracht al af te hebben minimaal een week vóór de inleverdatum, zodat we tijd hebben voor eventuele onverwachte verrassingen.

- Iedereen maakt gebruik van branches en pushed regelmatig, zodat niks verloren kan gaan en er altijd teruggedraaid kan worden.

- We maken gebruik van standups in de lessen (/online als het moet) zodat het voor iedereen duidelijk is wat er die dag gedaan moet worden.

- Als je niet aanwezig kan zijn bij de les or later naar de les komt, dan vermeld je dat in de discord. Als je te vaak niet aanwezig bent, dan moet je trakteren.

- Iemands werk wordt altijd gecontroleerd door andere team genoten, dan wel via een pull request of via discord.

- We overleggen met elkaar wie welke taken tot zich neemt, en komen tot een oplossing als meerdere teamgenoten dezelfde taak willen.

- We geven elkaar inhoudsvolle en duidelijke feedback, 'ziet er goed uit' is niet altijd genoeg.

- Hou je taken up-do-date in de sprintboard/github.

- Min. 2x per moet de hele groep bij elkaar komen, het liefst bij de lessen.  

 
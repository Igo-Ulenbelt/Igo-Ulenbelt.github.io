# De story
Als developer wil ik een template voor issues zodat het overzichtelijk is om te weten wat de issue is en welk probleem er word opgelost.

# Beschrijving
De developers moeten makkelijk kunnen zien wat de issue is en welke problemen worden opgelost. Een template kan hiermee helpen om een issue overzichtelijker te maken. In deze template moet een story, beschrijving, acceptatie criteria en wat de developer hiervan leert.

# Acceptance criteria
De template word pas geaccepteerd als er een goede story inzit, beschrijving, acceptatie criteria, wat de developer leert binnen de issue en wat hij moet uitleggen aan het groepje zodat zij het ook snappen.

# To Learn
## Leerdoel: Issues overzichtelijker maken voor developers zodat we weten waarmee we bezig zijn.

Bereid je zo voor dat je aan je groepje kunt uitleggen:
- Waarom de issue template zo uitgebreid is.
- Waarom er verschillende kopjes erin zitten.
- Wat het doel is van een goed gestructureerd issue.
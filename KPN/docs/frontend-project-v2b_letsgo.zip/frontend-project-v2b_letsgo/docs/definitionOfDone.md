# Definition of Done
- Het issue is netjes volgens de richtlijnen van het issue template aangemaakt.
- De code is netjes en leesbaar geschreven.
- De code is getest en werkt naar behoren.
- De branch is gedocumenteerd.
- De developer kan uitleggen hoe de code werkt.
- De branch wordt gereviewd door twee andere teamleden.
- Als een review commentaar heeft op een stuk code, wordt hierover gediscussieerd en wordt het eventueel aangepast.
- De branch wordt gemerged naar de main branch.